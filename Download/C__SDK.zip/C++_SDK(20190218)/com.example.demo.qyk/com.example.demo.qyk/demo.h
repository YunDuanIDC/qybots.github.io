#pragma once
const char * GetAppInfo();