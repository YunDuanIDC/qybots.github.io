#pragma once

typedef const char * CSTRING;
typedef std::vector<BYTE> BYTES;
typedef std::vector<INT64> INT64List;
