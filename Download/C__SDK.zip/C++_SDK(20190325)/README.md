QYBot SDK For C++
---
[![License](https://img.shields.io/github/license/Hstb1230/qybot-sdk.svg)](LICENSE)
[![Q群](https://img.shields.io/badge/Q%20%E7%BE%A4-529483966-orange.svg)](https://jq.qq.com/?_wv=1027&k=5McnWRW)
[![社区](https://img.shields.io/badge/%E7%A4%BE%E5%8C%BA-qyue.cc-blue.svg)](https://qyue.cc)

致歉说明
---
因学业繁忙，暂时抽不出时间编写详细说明，如有疑问请加群，看到后会进行回复。