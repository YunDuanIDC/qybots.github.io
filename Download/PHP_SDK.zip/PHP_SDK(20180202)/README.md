# HTTP-API-SDK
**包含PHP/Java/Python/NodeJS四种编程语言SDK。**   
**composer安装：composer require ksust/http-api-sdk**

| 名称 | 编程语言 | 最新版本 | 适配插件版本 | 备注 |   
| ------ | ------ | ------| ------ | ------ |   
| HTTP-API-SDK For PHP | PHP |2.3.0|2.3.0|-|   
| HTTP-API-SDK For Java | Java8 |2.3.0|2.3.0|-|   
| HTTP-API-SDK For Python | Python2/3 |2.3.0|2.3.0|-|   
| HTTP-API-SDK For NodeJS | NodeJS8 |2.3.0|2.3.0|-|   
 